package project;

import javafx.scene.control.ListView;

import java.sql.*;

public class Database {

    Connection connection;
    Statement statement;
    String playerName; //name
    int playerID;
    int currentQuestionID; //id of the current question
    int currentQuestionLow;
    int currentQuestionHigh;

    /**
     * Connects to Supabase cloud database
     * We'll reuse the Statement object to conduct queries
     */
    public Database(String playerName) {
        this.playerName = playerName;
        String url = "jdbc:postgresql://aws-1-us-east-2.pooler.supabase.com:5432/postgres";
        String user = "postgres.higsvtpuvaitfxvwnyqt";
        String pass = "PFWCS16!";

        System.out.println("Connecting to Supabase database...");
        try {
            connection = DriverManager.getConnection(url, user, pass);
            statement = connection.createStatement();

            //Get the player ID from the players table
            String query = "SELECT id FROM players WHERE name = ?;";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, playerName);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                playerID = rs.getInt("id");
            } else {
                //If player does not exist, insert them into the players table
                query = "INSERT INTO players (name) VALUES (?);";
                ps = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
                ps.setString(1, playerName);
                ps.executeUpdate();
                rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    playerID = rs.getInt(1);
                }
            }
            System.out.println("Connected as player: " + playerName + " (ID: " + playerID + ")");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Get a question that the player has not answered before
     * (i.e. does not have an entry in guesses table)
     *
     * @return Question prompt
     */
    public String getQuestion() {
        String query = "SELECT q.id, q.prompt, q.low, q.high FROM questions q " +
                "WHERE q.id NOT IN (SELECT g.question_id FROM guesses g WHERE g.player_id = ?) " +
                "ORDER BY RANDOM() LIMIT 1;";
        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, playerID);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                currentQuestionID = rs.getInt("id");
                currentQuestionHigh = rs.getInt("high");
                currentQuestionLow = rs.getInt("low");
                return rs.getString("prompt");
            } else {
                currentQuestionID = -1;
                return "All questions have been answered!";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public int getHigh() {
        return currentQuestionHigh;
    }

    public int getLow() {
        return currentQuestionLow;
    }
    /**
     * Get the answer for the current question
     */
    public int getAnswer() {
        String query = "SELECT answer FROM questions WHERE id = ?;";
        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, currentQuestionID);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("answer");
            } else {
                return -1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }

    /**
     * Add a player guess to the guesses table
     */
    public void submitGuess(int guess) {
        String query = "INSERT INTO guesses (player_id, question_id, guess) VALUES (?, ?, ?);";
        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, playerID);
            ps.setInt(2, currentQuestionID);
            ps.setInt(3, guess);
            ps.executeUpdate();
            //Guess logging
            System.out.println(String.format("Submitted guess %d for question ID %s by player ID %s", guess, currentQuestionID, playerID));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Populate a ListView with the leaderboard data for a given question
     *
     * @param leaderboard
     */
    public void getLeaderboard(String prompt, ListView leaderboard) {
        String query = "SELECT p.name, g.guess FROM guesses g " +
                "JOIN players p ON g.player_id = p.id " +
                "JOIN questions q ON g.question_id = q.id " +
                "WHERE q.prompt = ? " +
                "ORDER BY g.accuracy ASC;";
        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, prompt);
            ResultSet rs = ps.executeQuery();
            leaderboard.getItems().clear();
            while (rs.next()) {
                String name = rs.getString("name");
                int guess = rs.getInt("guess");
                leaderboard.getItems().add(String.format("%-15s: %,d", name, guess));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void clearGuesses() {
        String query = "DELETE FROM guesses WHERE player_id = ?;";
        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, playerID);
            ps.executeUpdate();
            System.out.println("Cleared all guesses for player ID " + playerID);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
