package project;

import javafx.animation.FadeTransition;
import javafx.animation.ParallelTransition;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class Controller {

    @FXML
    private Slider answerSL;
    @FXML
    private TextField answerTF;
    @FXML
    private BorderPane display;
    @FXML
    private ListView<String> leaderboardLV;
    @FXML
    private ListView<String> personalLV;
    @FXML
    private TextArea questionTA;
    @FXML
    private HBox resultBox;
    @FXML
    private HBox buttonBox;
    @FXML
    private Button guessB;

    Database db;

    String question;

    Media correctSound;
    Media tickSound;
    MediaPlayer correctMP;

    public void initialize() {
        //Connect to cloud database
//        populateDB(); For testing database with various player guesses
        correctSound = new Media(getClass().getResource("correct.mp3").toExternalForm());
        tickSound = new Media(getClass().getResource("tick.mp3").toExternalForm());
        correctMP = new MediaPlayer(correctSound);
        db = new Database("Tommy");
        nextQuestion(new ActionEvent());
        answerSL.valueProperty().addListener((obs, oldV, newV) -> {
            answerTF.setText(newV.intValue() + "");
            //Play tick sound
            MediaPlayer tickMP = new MediaPlayer(tickSound);
            tickMP.play();
        });

        personalLV.setCellFactory(lv -> new ListCell<>() {
            private boolean firstAppearance = true;

            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);

                if (empty || item == null) {
                    setText(null);
                    setGraphic(null);
                    return;
                }

                setText(item);

                // Animate only when the cell is first created or receives a new item
                if (firstAppearance) {
                    firstAppearance = false;

                    setOpacity(0);
                    setTranslateX(200);

                    FadeTransition fadeIn = new FadeTransition(Duration.millis(1000), this);
                    fadeIn.setFromValue(0.0);
                    fadeIn.setToValue(1.0);

                    TranslateTransition slideIn = new TranslateTransition(Duration.millis(1000), this);
                    slideIn.setByX(-200);

                    ParallelTransition allAnimations = new ParallelTransition(fadeIn, slideIn);
                    allAnimations.play();
                }
            }
        });

        //Make sure the buttons are clickable
        buttonBox.toFront();
    }

    public void populateDB() {
        //Populate database with player and guess data
        for (String name : new String[]{"Haley", "Marie", "Travis", "Michelle", "Sara"}) {
            db = new Database(name);
            db.clearGuesses();
            for (int i = 0; i < 10; i++) {
                String question = db.getQuestion();
                questionTA.setText(question);
                System.out.println("Question for " + name + ": " + question);
                db.submitGuess((int) (Math.random() * 100000));
                System.out.println("Answer is: " + db.getAnswer());
                //Display the leaderboard for the question
                db.getLeaderboard(question, leaderboardLV);
            }
        }
    }

    @FXML
    public void submitGuess(ActionEvent e){
        int guess = Integer.parseInt(answerTF.getText());
        db.submitGuess(guess);
        int answer = db.getAnswer();
        int accuracy = Math.abs(guess - answer);
        String result = "The answer is: " + answer + "!" + (accuracy > 0 ? " You were off by " + accuracy : "");
        resultBox.getChildren().clear();
        for (char c: result.toCharArray()){
            Text cText = new Text(c + "");
            resultBox.getChildren().add(cText);
        }

        //Sound for close guess within 10%
        if (accuracy < (db.getHigh() - db.getLow()) / 10) {
            correctMP.stop();
            correctMP.play();
        }
        personalLV.getItems().add(accuracy + "");
        db.getLeaderboard(question, leaderboardLV);
        guessB.setDisable(true);
    }

    @FXML
    public void nextQuestion(ActionEvent e){
        question = db.getQuestion();
        //Fade out first
        FadeTransition fadeOut = new FadeTransition(Duration.millis(500), questionTA);
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);
        fadeOut.setOnFinished(e2 -> {
            questionTA.setText(question);
            //Fade back in
            FadeTransition fadeIn = new FadeTransition(Duration.millis(500), questionTA);
            fadeIn.setFromValue(0.0);
            fadeIn.setToValue(1.0);
            fadeIn.play();
        });
        fadeOut.play();

        answerSL.setMax(db.getHigh());
        answerSL.setMin(db.getLow());
        double range = db.getHigh() - db.getLow();
        answerSL.setMajorTickUnit(range > 1000 ? range / 5 : range > 10 ? range / 10: 1);
        answerSL.setValue((db.getHigh() + db.getLow()) / 2);
        guessB.setDisable(false);

        for (Node c: resultBox.getChildren()){
            TranslateTransition randomMove = new TranslateTransition(Duration.millis(1000), c);
            randomMove.setByX(Math.random() * 400 - 200);
            randomMove.setByY(Math.random() * 400 - 200);

            FadeTransition cFadeOut = new FadeTransition(Duration.millis(1000), c);
            cFadeOut.setFromValue(1.0);
            cFadeOut.setToValue(0.0);

            ParallelTransition cAllAnimations = new ParallelTransition(randomMove, cFadeOut);

            cAllAnimations.setOnFinished(e2 -> {
                resultBox.getChildren().remove(c);
            });
            cAllAnimations.play();

        }
    }
}
