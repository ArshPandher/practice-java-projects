module main {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires javafx.base;
    requires javafx.media;

    opens project to javafx.fxml;
    exports project;
}
