import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import javafx.scene.control.Label;

/*
 * Handles all time-related calculations of soul 
 * currencies, bonus applications, etc.
 */
public class SoulManager {
	
	static float time;
	static int souls;
	static int soulsPerSecond;
	static Label soulsL;
	
	
	//Get some souls every 1s
	public SoulManager(Label soulsL, Reaper r, ArrayList<CultFollower> cfs) {
		this.soulsL = soulsL;
		souls = 0;
		soulsPerSecond = 1;
		time = 0;
//		start();		
//		this.t = t;
	}
	
	
	
}
