
public abstract class Reaper {
	
	String name;
	
	public Reaper(String name) {
		this.name = name;
	}
	
	abstract void permanentEffect();
	
	abstract void timeEffect();
	
}
