
public class CultFollower {
	
	static int internBoost = 1;
	static final int internCost = 25;
	
	static int assistantBoost = 10;
	static final int assistantCost = 250;
	
	static int managerBoost = 100;
	static final int managerCost = 2500;
	
	static int janitorBoost = 1000;
	static int janitorCost = 25000;
}
