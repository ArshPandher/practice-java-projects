import java.util.Timer;
import java.util.TimerTask;

import javafx.animation.*;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class IdleSouls extends Application{
	public static void main(String[] args) {
		launch(args);
	}
	
	public void start(Stage stage) {
		
		//Data
		Label soulsCount = new Label("");
		SoulManager sl = new SoulManager(soulsCount);
		Agency startAgency = new Agency("Shoe Store");
		
		
		ImageView soulImg = new ImageView(new Image("file:Soul.png"));
		Label agencyTitle = new Label(startAgency.name);
		BorderPane agencyDisplay = new BorderPane(soulImg);
		agencyDisplay.setTop(agencyTitle);
		
		BorderPane main = new BorderPane(agencyDisplay);
		
		HBox upgradeMenu = new HBox();
		
		Label gameTitle = new Label("Idol Soles");
		ImageView scytheImg = new ImageView(new Image("file:scytheplaceholder.jpg"));
		scytheImg.setFitWidth(50);
		scytheImg.setPreserveRatio(true);
		
		Button agencyButton = new Button("Manage Agencies");
		Button reaperButton = new Button("Hire a Reaper");
		Button cultFollowersButton = new Button("Buy More Cult Followers");
		
		upgradeMenu.getChildren().addAll(gameTitle, scytheImg, agencyButton, reaperButton, cultFollowersButton);
		
		Label day = new Label("Current Day: ");
		
		Label soulsText = new Label("Souls: ");
		
		HBox soulsDisplay = new HBox(soulsText, soulsCount);
		
		main.setBottom(soulsDisplay);
		
		main.setTop(upgradeMenu);
		
		Scene s = new Scene(main, 1000, 800);
		
//		CultShop cs = new CultShop();
		
		
		Image bobImg = new Image("file:images/unpaidintern.jpg");
		ImageView reaperHireImg = new ImageView(bobImg);
		reaperHireImg.setFitHeight(75);
		reaperHireImg.setPreserveRatio(true);
		
		//Reaper shop window
		GridPane reaperShop = new GridPane();
		
		Label bobTitle = new Label("Bob");
		Label bobDescription = new Label("Bob likes interns.");
		VBox bobBox = new VBox(bobTitle, bobDescription);
		Button bobHire = new Button("Hire");
		
		reaperShop.add(reaperHireImg, 0, 0);
		reaperShop.add(bobBox, 1, 0);
		reaperShop.add(bobHire, 2, 0);
		
		//Reaper View window
		GridPane reaperView = new GridPane();
		ImageView reaperViewImg = new ImageView(bobImg);
		reaperViewImg.setFitHeight(75);
		reaperViewImg.setPreserveRatio(true);
		Label reaperTitle = new Label("Bob");
		Label reaperDescription = new Label("Bob likes interns");
		VBox reaperText = new VBox(reaperTitle, reaperDescription);
		Button fireReaper = new Button("Fire");
		
		reaperView.add(reaperText, 0, 0);
		reaperView.add(fireReaper, 1, 0);
		reaperView.add(reaperViewImg, 0, 1, 2, 3);
		
		bobHire.setOnAction(event -> {
			reaperButton.setText("View Reaper");
			startAgency.hireReaper(new Reaper("Bob"));
			main.setRight(reaperView);
		});
		
		fireReaper.setOnAction(event -> {
			reaperButton.setText("Hire Reaper");
			startAgency.fireReaper();
			main.setRight(reaperShop);
		});
		
		reaperButton.setOnAction(event -> {
			if (startAgency.hasReaper()){
				main.setRight(reaperView);
			}
			else {
				main.setRight(reaperShop);
			}
		});
		
		stage.setScene(s);
		stage.show();
		
		
		
		
		
		
		
		
		
		long delay = 1000L;

		TimerTask task = new TimerTask() {
			public void run() {
				
				TimerTask runIt = new TimerTask() {
					public void run() {
						sl.souls += sl.soulsPerSecond;
						sl.soulsL.setText(sl.souls + "");
						sl.time += delay / 1000;
					}
				};
				Platform.runLater(runIt);
			}
		};


		
		Timer t = new Timer();
		
		t.scheduleAtFixedRate(task, 0, delay);

	}
}
