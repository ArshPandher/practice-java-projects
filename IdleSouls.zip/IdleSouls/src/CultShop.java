import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;

//Cult Follower Window
public class CultShop extends GridPane{

	public CultShop() {
		Button internBtn = new Button("Unpaid Intern");
//		internBtn.setGraphic();
		Label internLbl = new Label("Owned: ");
		Label internCount = new Label("");
		
		add(internBtn, 0, 0);
		add(internLbl, 1, 0);
		add(internCount, 2, 0);
		
		internBtn.setOnAction(event -> {
			if (sl.souls >= CultFollower.internCost) {
				sl.souls -= CultFollower.internCost;
				startAgency.internCount++;
				sl.soulsPerSecond += CultFollower.internBoost;
			}
		});
		
		
		cultFollowersButton.setOnAction(event -> {
			main.setRight(cultFollowerShop);
		});
	}		
}
