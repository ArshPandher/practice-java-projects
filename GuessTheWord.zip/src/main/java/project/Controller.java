package project;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Scanner;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;

public class Controller {

	@FXML
	private ImageView creeperIV;

	@FXML
	private GridPane gameGP;

	@FXML
	private Label guessLettersLbl;

	@FXML
	private TextField guessTxt;

	@FXML
	private ImageView ryanIV;

	@FXML
	private Label wordLbl;
	
	@FXML
	private Label resultLbl;

	private int guessesLeft;

	//Word object to handle the game data
	private Word word;

	private int guessCount;
	
	@FXML
	void initialize() throws IOException, InterruptedException {
		//Game setup
		guessesLeft = 6;
		guessCount = 0;
		
		word = new Word();
		updateWordDisplay();
		
		//Previous manual testing
		//		Scanner checker = new Scanner(System.in);
		//		while (true) {
		//			String guess = checker.nextLine();
		//			word.guess(guess);
		//		}
	}

	@FXML
	public void guess() {
		//TODO
		boolean valid = word.guess(guessTxt.getText());
		updateWordDisplay();
		
		if (valid) {
			guessesLeft--;
			guessCount++;
			
			gameGP.getChildren().remove(ryanIV);
			gameGP.add(ryanIV, guessCount, 0);
		}
		
		checkWinOrLose();
	}

	public void updateWordDisplay() {
		StringBuilder guessProgress = word.getGuessProgress();
		wordLbl.setText(guessProgress.toString());
		guessLettersLbl.setText(word.getGuessedLetters());
	}

	public void checkWinOrLose() {
		if (!word.getGuessProgress().toString().contains("_")) {
			resultLbl.setText("You Win!");
		}
		else if (guessesLeft == 0) {
			resultLbl.setText("You Lose...");
		}
	}


}
