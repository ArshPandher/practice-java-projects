package project;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class Word {

	private String word;
	private StringBuilder guessProgress;
	
	private String guessedLetters;

	public Word() throws IOException, InterruptedException {
		//Get a word from an Internet API
		//From RapidAPI random-words
		HttpRequest request = HttpRequest.newBuilder()
				.uri(URI.create("https://random-word-api.p.rapidapi.com/L/3"))
				.header("X-RapidAPI-Key", "52af9ce6b1msh6b20c18c3439862p11a651jsn51cbed85b1d5")
				.header("X-RapidAPI-Host", "random-word-api.p.rapidapi.com")
				.method("GET", HttpRequest.BodyPublishers.noBody())
				.build();
		HttpResponse<String> response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());

		word = response.body().split("\"")[3];
		System.out.println("The word is: " + word);

		guessedLetters = "";
		
		//The currently guessed letters will be filled into guessProgress
		//Begins as empty spaces for each character
		guessProgress = new StringBuilder("_".repeat(word.length()));
		System.out.println("Guess progress is: " + guessProgress.toString());
	}

	/**
	 * Submits a guess to the current word
	 * Updates guessProgress at the guessed letter locations
	 * @param guess The player's guess
	 * @return true = guess was valid, false = already guessed
	 */
	public boolean guess(String guess) {

		if (!guessedLetters.contains(guess))
		{
			int found = word.indexOf(guess);

			while (found != -1) {
				//TODO Change blank to letter
				System.out.println("Found " + guess);
				guessProgress.replace(found, found + 1, guess);
				found = word.indexOf(guess, found + 1);
			}

			guessedLetters += guess;
		}
		else {
			//Already guessed
			return false;
		}

		return true;
	}
	
	public StringBuilder getGuessProgress() {
		return guessProgress;
	}

	public String getGuessedLetters() {
		return guessedLetters;
	}

}
