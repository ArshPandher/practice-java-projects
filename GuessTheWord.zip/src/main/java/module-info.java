module main {
    requires javafx.controls;
    requires javafx.fxml;
	requires org.apache.httpcomponents.httpclient;
	requires org.apache.httpcomponents.httpcore;
	requires java.net.http;

    opens project to javafx.fxml;
    exports project;
}
