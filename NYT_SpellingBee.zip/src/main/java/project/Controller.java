package project;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Scanner;

import javafx.animation.PauseTransition;
import javafx.animation.RotateTransition;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

public class Controller {

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private Button b;

	@FXML
	private Button bl;

	@FXML
	private Button br;

	@FXML
	private Button requiredL;

	@FXML
	private Button t;

	@FXML
	private Button tl;

	@FXML
	private Button tr;

	@FXML
	private TextField wordTxt;

	@FXML
	private VBox wordsBox;

	String word = "";
	String required;
	ArrayList<String> words;
	ArrayList<String> submittedWords;

	public void initialize() throws FileNotFoundException {
		required = requiredL.getText();

		words = new ArrayList<>();
		submittedWords = new ArrayList<>();

		Scanner wordReader = new Scanner(new File("words.txt"));

		while(wordReader.hasNext()) {
			//Now everything is uppercase
			words.add(wordReader.nextLine().toUpperCase());
		}

		System.out.println(words);
	}

	@FXML
	void addLetter(ActionEvent event) {
		Button source = (Button)event.getSource();
		String letter = source.getText();
		word += letter;
		wordTxt.setText(word);
		requiredL.setOnAction(e -> {
			System.out.println("Now I just print Hi!");
		});
	}

	@FXML
	void removeLetter(ActionEvent event) {
		word = word.length() > 0 ? word.substring(0, word.length()-1): word;
		wordTxt.setText(word);
	}

	@FXML
	void shuffleLetters(ActionEvent event) {
		Button[] outsideButtons = {b, bl, br,
									t, tl, tr};
		//Swap button text enough times to feel random
		for (int i = 0; i < 1000; i++) {
			int rand1 = (int)(Math.random() * outsideButtons.length); 
			String temp = outsideButtons[rand1].getText();
			int rand2 = (int)(Math.random() * outsideButtons.length);
			outsideButtons[rand1].setText(outsideButtons[rand2].getText());
			outsideButtons[rand2].setText(temp);
		}
	}

	@FXML
	void submitWord(ActionEvent event) {
		if (word.contains(required)) {
			if (words.contains(word)) {
				if (!submittedWords.contains(word)) {
					wordsBox.getChildren().add(new Label(word));
					submittedWords.add(word);
				}
			}
		}
		else {
			wordTxt.setText("Invalid word!");
			
			RotateTransition shake = new RotateTransition(Duration.millis(100), wordTxt);
	        shake.setCycleCount(4); // Shake 4 times (2 full oscillations)
	        shake.setAutoReverse(true); // Back and forth motion
	        shake.setFromAngle(-5);
	        shake.setByAngle(10); // Degrees to shake (adjust as needed)
			shake.play();
			shake.setOnFinished(e -> {
				wordTxt.setRotate(0);
			});
			
			PauseTransition pause = new PauseTransition(Duration.seconds(1));
			pause.setOnFinished(e -> {
				// Run the action after the pause
				Platform.runLater(() -> {
					wordTxt.setText("");
				});
			});

			pause.play();
		}
		word = "";
	}

}
