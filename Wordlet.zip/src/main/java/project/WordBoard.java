package project;
import java.util.ArrayList;

import javafx.animation.Animation;
import javafx.animation.FadeTransition;
import javafx.animation.FillTransition;
import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.RotateTransition;
import javafx.animation.ScaleTransition;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.util.Duration;

public class WordBoard extends GridPane{

	private String word;
	private String guess;
	private int guessMax;
	private int guessCount;
	private Label[][] letterGrid;
	private int letterCurrentIndex;
	private boolean completed;

	public void addLetter(String letter) {
		letter = letter.toLowerCase();
		if (letterCurrentIndex < letterGrid[guessCount].length) {
			letterGrid[guessCount][letterCurrentIndex].setText(letter);
			guess += letter;
			
			ScaleTransition pulse = new ScaleTransition(Duration.millis(100), letterGrid[guessCount][letterCurrentIndex]);
			pulse.setByX(.15);
			pulse.setByY(.15);
			pulse.setAutoReverse(true);
			pulse.setCycleCount(2);
			pulse.play();
			
			letterCurrentIndex++;
		}
	}

	public void removeLetter() {
		if (letterCurrentIndex > 0) {
			letterGrid[guessCount][letterCurrentIndex - 1].setText("");
			letterCurrentIndex--;
			guess.substring(0, guess.length() - 1);
		}
	}

	public WordBoard(String word, int guessMax) {
		this.word = word;
		guess = "";
		this.guessMax = guessMax;
		completed = false;
		letterCurrentIndex = 0;

		int gap = 10;
		setVgap(gap);
		setHgap(gap);
		setPadding(new Insets(10));
		setAlignment(Pos.CENTER);

		//Create word space
		letterGrid = new Label[guessMax][5];

		for (int row = 0; row < letterGrid.length; row++) {
			for (int col = 0; col < letterGrid[row].length; col++) {
				letterGrid[row][col] = new Label(" ");
				letterGrid[row][col].setPrefWidth(60);
				letterGrid[row][col].setAlignment(Pos.CENTER);

				letterGrid[row][col].setStyle("-fx-background-color: lightgrey");
				add(letterGrid[row][col], col, row);
			}
		}
	}

	public boolean guess() {
		try {
			
			if (!completed) {
				char[] wordLetters = word.toLowerCase().toCharArray();
				char[] guessLetters = guess.toLowerCase().toCharArray();
				boolean[] letterCompleted = new boolean[wordLetters.length];

				for (int i = 0; i < guessLetters.length; i++) {

					//Flip letter
					ScaleTransition flipLetter = new ScaleTransition(Duration.millis(1000), letterGrid[guessCount][i]);
					flipLetter.setToY(-1);
					flipLetter.setAutoReverse(true);
					flipLetter.setCycleCount(2);
					flipLetter.play();
					
					RotateTransition tiltLetter = new RotateTransition(Duration.millis(650), letterGrid[guessCount][i]);
					tiltLetter.setByAngle(5);
					tiltLetter.setAutoReverse(true);
					tiltLetter.setCycleCount(2);
					tiltLetter.play();
					
					
					letterGrid[guessCount][i].setText(guessLetters[i] + "");
					
					for (int j = 0; j < wordLetters.length; j++)

						
						
						//if the guessed letter is in the word somewhere
						if (guessLetters[i] == wordLetters[j] && !letterCompleted[j]) {
							letterGrid[guessCount][i].setStyle("-fx-background-color: yellow");

							//if the guess letter is the same location as the word letter
							if (i == j) {
								letterCompleted[j] = true;
								letterGrid[guessCount][j].setStyle("-fx-background-color: green");
								break;
							}
						}
				}

				guessCount++;

				if (guess.equals(word)){
					completed = true;
					return true;
				}
				else {
					return false;
				}
			}
			else {
				return true;
			}
		}
		//Clear the guess regardless of result
		finally {
			guess = "";
			letterCurrentIndex = 0;
		}


	}
	
	public void explode() {
		
		for (Label[] row: letterGrid) {
			for (Label letter: row) {
				
				double speed = 8;
				double deltaX = Math.random() * speed - speed / 2;
				double deltaY = Math.random() * speed - speed / 2;
				
				Timeline explode = new Timeline(new KeyFrame(Duration.millis(10), e -> {
					
					letter.setTranslateX(letter.getTranslateX() + deltaX);
					letter.setTranslateY(letter.getTranslateY() + deltaY);
					
				}));
				
				explode.setCycleCount(Animation.INDEFINITE);
				explode.play();
				
			}
		}
		
	}


}
