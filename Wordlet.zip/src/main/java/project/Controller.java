package project;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class Controller {

	private static int guessMax = 6;
	private static int wordCount = 1;
	private static WordBoard[] wordBoards;
	private static HBox board;
	private static HBox guessBox;
	private static Button guessBtn;
	private static Stage startMenu;
	
	private static ArrayList<String> wordList = new ArrayList<>();
	
	@FXML
	BorderPane display;
	
	public void initialize() {
//		display.getStylesheets().add("style.css");
		
		readWords();
		
		board = new HBox();
		
		guessBtn = new Button("Guess");
		guessBtn.setDefaultButton(true);
		
		guessBox = new HBox(guessBtn);
		guessBox.setAlignment(Pos.CENTER);
		
		MenuBar mb = new MenuBar();
		Menu gameMenu = new Menu("Game");
		mb.getMenus().add(gameMenu);
		MenuItem restart = new MenuItem("Restart");
		gameMenu.getItems().add(restart);
		
		restart.setOnAction(event -> {
			startMenu();
		});
		
		display.setCenter(board);
		display.setTop(mb);
		display.setBottom(guessBox);
		
		//Word event
		guessBtn.setOnAction(event -> {
			
			boolean didAnyLose = false;
			
			//TODO Make sure guess is right length
			for (int i = 0; i < wordBoards.length; i++) {
				if (wordBoards[i].guess() == false) {
					didAnyLose = true;
				}
			}
			
			//win check
			//TODO Check for all boards
			if (!didAnyLose) {
				
				//Victory animation
				for (WordBoard wb: wordBoards) {
					wb.explode();
				}
				
				//Victory music
				File f = new File("win.mp3");
//				Media song = new Media(f.toURI().toString());
//				MediaPlayer player = new MediaPlayer(song);
//				player.play();
				
				guessBtn.setDisable(true);
			}
		});
		
		//On key press, add a letter to the grid
		display.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
			for (WordBoard wb: wordBoards) {
				if (event.getCode() == KeyCode.BACK_SPACE || event.getCode() == KeyCode.DELETE) {
					wb.removeLetter();
				}
				else if (event.isAltDown() && event.getCode() == KeyCode.R) {
					startMenu.show();
				}
				else if (event.getCode() != KeyCode.ENTER && event.getCode() != KeyCode.ALT){
					wb.addLetter(event.getCode().toString());
				}
				
			}
		});
		
		
		startMenu();
	}
	
	static void startGame() {
		guessBtn.setDisable(false);
		board.getChildren().clear();
		wordBoards = new WordBoard[wordCount];
		
		for (int i = 0; i < wordBoards.length; i++) {
			wordBoards[i] = new WordBoard(chooseWord(), guessMax);
			board.getChildren().add(wordBoards[i]);
		}
	}
	
	static void startMenu() {
		startMenu = new Stage();
		startMenu.toFront();
		
		Label wordL = new Label("Word Count: ");
		TextField wordT = new TextField(wordCount + "");
		Label guessL = new Label("Guess Count: ");
		TextField guessT = new TextField(guessMax + "");
					
		GridPane settingsGrid = new GridPane();
		settingsGrid.add(wordL, 0, 0);
		settingsGrid.add(wordT, 1, 0);
		settingsGrid.add(guessL, 0, 1);
		settingsGrid.add(guessT, 1, 1);
		
		settingsGrid.setOnKeyPressed(e ->{
			if (e.getCode() == KeyCode.ENTER) {
				int wordCountNew = Integer.parseInt(wordT.getText());
				wordCount = wordCountNew;
				int guessMaxNew = Integer.parseInt(guessT.getText());
				guessMax = guessMaxNew;
				startGame();
				startMenu.hide();
			}
			else if (e.getCode() == KeyCode.ESCAPE) {
				System.exit(0);
			}
		});

		BorderPane startDisplay = new BorderPane(settingsGrid);
		startDisplay.setBottom(new Label("Press enter to start"));
		
		Scene scene = new Scene(startDisplay);
		scene.getStylesheets().add(Controller.class.getResource("style.css").toExternalForm());;
		startMenu.setScene(scene);
		startMenu.show();
		wordT.requestFocus();
	}
	
	static void readWords() {
		
		try {
			File f = new File("wordList5.txt");
			Scanner reader = new Scanner(f);
		
			//Read all the words
			while (reader.hasNext()) {
				wordList.add(reader.nextLine());
			}
			
			reader.close();
		} catch (IOException e) {
			System.out.println("File Error");
		}
		
		
	}
	
	static String chooseWord() {
		Random r = new Random();
		
		String word = wordList.remove(r.nextInt(wordList.size()));
		System.out.println(word);
		
		return word;
	}
}
